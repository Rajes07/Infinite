package com.java.spring.enume;

public enum MenuStatus {
	AVAILABLE,NOTAVAILABLE
}
